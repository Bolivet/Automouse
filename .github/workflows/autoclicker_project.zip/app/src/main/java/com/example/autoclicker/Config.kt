package com.example.autoclicker

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

class Target(var type: Int, var x: Int, var y: Int, var x2: Int = 0, var y2: Int = 0) {
    fun toJson(): JSONObject = JSONObject().put("t", type).put("x", x).put("y", y).put("x2", x2).put("y2", y2)
    companion object {
        fun from(o: JSONObject) = Target(o.getInt("t"), o.getInt("x"), o.getInt("y"), o.optInt("x2"), o.optInt("y2"))
    }
}

object Config {
    var mode = 1 // 0 단일, 1 다중
    val single = mutableListOf<Target>()
    val multi = mutableListOf<Target>()
    var intervalMs = 500L
    var repeat = 0 // 0 = 무한
    var pauseOnTouch = true
    var resumeDelayMs = 1000L
    var jitter = 0
    private lateinit var p: SharedPreferences

    val targets: MutableList<Target> get() = if (mode == 0) single else multi

    fun init(c: Context) {
        if (::p.isInitialized) return
        p = c.applicationContext.getSharedPreferences("ac", 0)
        p.getString("cur", null)?.let { try { apply(JSONObject(it)) } catch (_: Exception) {} }
    }

    private fun arr(l: List<Target>): JSONArray { val a = JSONArray(); l.forEach { a.put(it.toJson()) }; return a }
    private fun fill(l: MutableList<Target>, a: JSONArray?) {
        l.clear(); if (a != null) for (i in 0 until a.length()) l.add(Target.from(a.getJSONObject(i)))
    }

    fun snapshot(): JSONObject = JSONObject()
        .put("single", arr(single)).put("multi", arr(multi))
        .put("i", intervalMs).put("r", repeat).put("pt", pauseOnTouch)
        .put("rd", resumeDelayMs).put("j", jitter)

    fun apply(o: JSONObject) {
        fill(single, o.optJSONArray("single")); fill(multi, o.optJSONArray("multi"))
        intervalMs = o.optLong("i", 500); repeat = o.optInt("r", 0)
        pauseOnTouch = o.optBoolean("pt", true); resumeDelayMs = o.optLong("rd", 1000); jitter = o.optInt("j", 0)
    }

    fun saveCurrent() { p.edit().putString("cur", snapshot().toString()).apply() }

    private fun presets() = JSONObject(p.getString("presets", "{}")!!)
    fun presetNames(): List<String> = presets().keys().asSequence().toList().sorted()
    fun savePreset(name: String) { p.edit().putString("presets", presets().put(name, snapshot()).toString()).apply() }
    fun loadPreset(name: String) { presets().optJSONObject(name)?.let { apply(it); saveCurrent() } }
    fun deletePreset(name: String) { val o = presets(); o.remove(name); p.edit().putString("presets", o.toString()).apply() }
    fun renamePreset(old: String, new: String) {
        val o = presets(); val v = o.optJSONObject(old) ?: return
        o.remove(old); o.put(new, v); p.edit().putString("presets", o.toString()).apply()
    }
}
