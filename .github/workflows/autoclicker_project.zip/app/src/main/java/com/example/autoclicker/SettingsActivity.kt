package com.example.autoclicker

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class SettingsActivity : Activity() {
    private lateinit var fInterval: EditText
    private lateinit var fRepeat: EditText
    private lateinit var fResume: EditText
    private lateinit var fJitter: EditText
    private lateinit var swPause: Switch
    private lateinit var fName: EditText
    private lateinit var list: LinearLayout
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        Config.init(this)
        title = "설정"
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(12), dp(16), dp(24)) }
        setContentView(ScrollView(this).apply { addView(root) })

        fun label(t: String) = root.addView(TextView(this).apply { text = t; setPadding(0, dp(12), 0, 0) })
        fun num(): EditText { val e = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER }; root.addView(e); return e }

        label("클릭 간격 (ms)"); fInterval = num()
        label("반복 횟수 (0 = 무한)"); fRepeat = num()
        swPause = Switch(this).apply { text = "터치하면 잠깐 멈췄다가 자동 재개"; setPadding(0, dp(16), 0, 0) }
        root.addView(swPause)
        label("재개 대기 시간 (ms) — 터치 후 이 시간이 지나면 다시 시작"); fResume = num()
        label("위치 흔들림 (px, 0 = 끄기)"); fJitter = num()
        fillFields()

        root.addView(TextView(this).apply { text = "프리셋"; textSize = 18f; setPadding(0, dp(28), 0, 0) })
        fName = EditText(this).apply { hint = "프리셋 이름"; inputType = InputType.TYPE_CLASS_TEXT }
        root.addView(fName)
        root.addView(Button(this).apply {
            text = "현재 설정 저장"
            setOnClickListener {
                val n = fName.text.toString().trim()
                if (n.isEmpty()) { toast("이름을 입력하세요"); return@setOnClickListener }
                applyFields(); Config.savePreset(n); fName.setText(""); toast("저장했어요"); render()
            }
        })
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list)
        render()
    }

    private fun fillFields() {
        fInterval.setText(Config.intervalMs.toString()); fRepeat.setText(Config.repeat.toString())
        swPause.isChecked = Config.pauseOnTouch
        fResume.setText(Config.resumeDelayMs.toString()); fJitter.setText(Config.jitter.toString())
    }

    private fun applyFields() {
        Config.intervalMs = (fInterval.text.toString().toLongOrNull() ?: 500L).coerceAtLeast(10L)
        Config.repeat = fRepeat.text.toString().toIntOrNull() ?: 0
        Config.pauseOnTouch = swPause.isChecked
        Config.resumeDelayMs = fResume.text.toString().toLongOrNull() ?: 1000L
        Config.jitter = fJitter.text.toString().toIntOrNull() ?: 0
        Config.saveCurrent()
    }

    private fun render() {
        list.removeAllViews()
        Config.presetNames().forEach { name ->
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            row.addView(TextView(this).apply { text = name; textSize = 16f }, LinearLayout.LayoutParams(0, -2, 1f))
            fun b(t: String, f: () -> Unit) = row.addView(Button(this).apply { text = t; isAllCaps = false; setOnClickListener { f() } })
            b("불러오기") { Config.loadPreset(name); fillFields(); toast("불러왔어요") }
            b("이름변경") { ask("새 이름", name) { n -> if (n.isNotEmpty()) { Config.renamePreset(name, n); render() } } }
            b("삭제") { Config.deletePreset(name); render() }
            list.addView(row)
        }
    }

    private fun ask(title: String, def: String, cb: (String) -> Unit) {
        val e = EditText(this).apply { setText(def) }
        AlertDialog.Builder(this).setTitle(title).setView(e)
            .setPositiveButton("확인") { _, _ -> cb(e.text.toString().trim()) }
            .setNegativeButton("취소", null).show()
    }

    override fun onPause() { applyFields(); super.onPause() }
    override fun onStop() { AutoClickService.instance?.refreshMarkers(); super.onStop() }
}
