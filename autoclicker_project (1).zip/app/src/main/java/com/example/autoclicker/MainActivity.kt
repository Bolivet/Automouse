package com.example.autoclicker

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var b0: Button
    private lateinit var b1: Button
    private lateinit var status: TextView
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        Config.init(this)
        title = "Auto Clicker"
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(12), dp(12), dp(12)) }
        setContentView(ScrollView(this).apply { setBackgroundColor(0xFFFAFAFA.toInt()); addView(root) })

        fun card(name: String, vararg rows: Pair<String, () -> Unit>): Button {
            val c = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(12), dp(16), dp(12))
                background = GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = dp(8).toFloat(); setStroke(1, 0xFFDDDDDD.toInt()) }
            }
            c.addView(TextView(this).apply { text = name; textSize = 18f; setTextColor(Color.BLACK) })
            rows.forEach { (t, f) -> c.addView(Button(this).apply { text = t; isAllCaps = false; setOnClickListener { f() } }) }
            val toggle = Button(this).apply { text = "활성화" }
            c.addView(toggle)
            root.addView(c, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
            return toggle
        }
        val toSettings = { startActivity(Intent(this, SettingsActivity::class.java)) }
        b0 = card("단일 타겟 모드", "설정" to toSettings)
        b1 = card("다중 타겟 모드", "설정" to toSettings, "사용 설명" to { help() }, "프리셋 관리" to toSettings)
        b0.setOnClickListener { toggle(0) }
        b1.setOnClickListener { toggle(1) }
        status = TextView(this).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, 0) }
        root.addView(status)
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        val svc = AutoClickService.instance
        val m = svc?.shownMode ?: -1
        b0.text = if (m == 0) "비활성화" else "활성화"
        b1.text = if (m == 1) "비활성화" else "활성화"
        status.text = "접근성: ${if (svc != null) "ON" else "OFF"}   |   다른 앱 위에 표시: ${if (Settings.canDrawOverlays(this)) "ON" else "OFF"}"
    }

    private fun toggle(mode: Int) {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "'다른 앱 위에 표시'를 허용해 주세요", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))); return
        }
        val svc = AutoClickService.instance
        if (svc == null) {
            Toast.makeText(this, "접근성에서 '오토클릭커'를 켜 주세요", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); return
        }
        if (svc.shownMode == mode) svc.hide() else svc.show(mode)
        refresh()
    }

    private fun help() {
        AlertDialog.Builder(this).setTitle("사용 설명").setMessage(
            "1. 활성화를 누르면 컨트롤 바가 나타나요.\n" +
            "2. ＋ 클릭 지점 추가, ⤴ 스와이프 추가, － 마지막 지점 삭제\n" +
            "3. 번호 원을 드래그해서 위치를 맞춰요.\n" +
            "4. ▶ 시작 / ⏸ 정지, ✥ 로 바 이동, ⚙ 설정\n" +
            "5. 실행 중 화면을 직접 터치하면 잠깐 멈췄다가 설정한 시간 뒤 자동으로 다시 시작해요.\n" +
            "6. 실행 중 볼륨 아래 키를 누르면 바로 정지돼요."
        ).setPositiveButton("확인", null).show()
    }
}
