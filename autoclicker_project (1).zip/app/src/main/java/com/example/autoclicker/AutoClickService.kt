package com.example.autoclicker

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.WindowManager.LayoutParams as WLP
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.random.Random

class AutoClickService : AccessibilityService() {
    companion object { var instance: AutoClickService? = null }

    private lateinit var wm: WindowManager
    private val h = Handler(Looper.getMainLooper())
    private var bar: LinearLayout? = null
    private var barLp: WLP? = null
    private var watcher: View? = null
    private val markers = mutableListOf<TextView>()
    private var playBtn: TextView? = null
    var shownMode = -1
        private set
    private var running = false
    private var idx = 0
    private var loops = 0
    private var lastUser = 0L
    private var gestureUntil = 0L
    private var eventUntil = 0L
    private var barDown = false

    override fun onServiceConnected() {
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        Config.init(this)
    }
    // 보조 감지: 우리가 누른 직후가 아닌데 클릭/스크롤 이벤트가 오면 사용자 터치로 간주
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (running && SystemClock.uptimeMillis() > eventUntil) lastUser = SystemClock.uptimeMillis()
    }

    // 실행 중 볼륨 아래 키 = 즉시 정지
    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (running && event.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            if (event.action == KeyEvent.ACTION_DOWN) h.post { stop() }
            return true
        }
        return false
    }
    override fun onInterrupt() {}
    override fun onUnbind(i: Intent?): Boolean { hide(); instance = null; return super.onUnbind(i) }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun mk(w: Int, hh: Int, flags: Int) =
        WLP(w, hh, WLP.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START }
    private fun markerFlags(touchable: Boolean) =
        WLP.FLAG_NOT_FOCUSABLE or WLP.FLAG_LAYOUT_NO_LIMITS or WLP.FLAG_LAYOUT_IN_SCREEN or (if (touchable) 0 else WLP.FLAG_NOT_TOUCHABLE)

    fun show(m: Int) {
        hide(); Config.mode = m; shownMode = m

        // 사용자 터치 감지용 (화면 터치를 막지 않음)
        val w = View(this)
        w.setOnTouchListener { _, ev ->
            if (ev.action == MotionEvent.ACTION_OUTSIDE && SystemClock.uptimeMillis() > gestureUntil)
                lastUser = SystemClock.uptimeMillis()
            false
        }
        wm.addView(w, mk(1, 1, WLP.FLAG_NOT_FOCUSABLE or WLP.FLAG_NOT_TOUCH_MODAL or WLP.FLAG_WATCH_OUTSIDE_TOUCH))
        watcher = w

        // 플로팅 컨트롤 바
        val b = object : LinearLayout(this@AutoClickService) {
            // 바를 누르는 동안에는 자동 클릭을 멈춰서 버튼이 확실히 눌리게 함
            override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
                when (ev.action) {
                    MotionEvent.ACTION_DOWN -> { barDown = true; lastUser = SystemClock.uptimeMillis() }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { barDown = false; lastUser = SystemClock.uptimeMillis() }
                }
                return super.dispatchTouchEvent(ev)
            }
        }.apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply { setColor(0xDD222222.toInt()); cornerRadius = dp(12).toFloat() }
        }
        fun btn(t: String, c: Int, f: () -> Unit) = TextView(this).apply {
            text = t; textSize = 22f; setTextColor(c); gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(dp(48), dp(48)); setOnClickListener { f() }
        }
        val pb = btn("▶", 0xFF4C8DFF.toInt()) { if (running) stop() else start() }
        playBtn = pb
        b.addView(pb)
        b.addView(btn("＋", 0xFF43A047.toInt()) { addTarget(0) })
        b.addView(btn("⤴", 0xFFFFA726.toInt()) { addTarget(1) })
        b.addView(btn("－", 0xFFE64A19.toInt()) { removeLast() })
        b.addView(btn("⚙", Color.LTGRAY) {
            stop(); startActivity(Intent(this, SettingsActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        })
        val mv = btn("✥", Color.LTGRAY) {}
        var dx = 0f; var dy = 0f; var sx = 0; var sy = 0
        val bp = mk(WLP.WRAP_CONTENT, WLP.WRAP_CONTENT, markerFlags(true)).apply { x = 0; y = dp(200) }
        mv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = bp.x; sy = bp.y }
                MotionEvent.ACTION_MOVE -> {
                    bp.x = sx + (e.rawX - dx).toInt(); bp.y = sy + (e.rawY - dy).toInt()
                    wm.updateViewLayout(b, bp)
                }
            }
            true
        }
        b.addView(mv)
        b.addView(btn("✕", Color.LTGRAY) { hide() })
        wm.addView(b, bp); bar = b; barLp = bp

        refreshMarkers()
    }

    fun hide() {
        running = false; h.removeCallbacks(tick)
        if (!::wm.isInitialized) return
        markers.forEach { try { wm.removeView(it) } catch (_: Exception) {} }; markers.clear()
        bar?.let { try { wm.removeView(it) } catch (_: Exception) {} }; bar = null
        watcher?.let { try { wm.removeView(it) } catch (_: Exception) {} }; watcher = null
        shownMode = -1
    }

    private fun addTarget(type: Int) {
        if (running) return
        val ts = Config.targets
        if (Config.mode == 0 && (ts.isNotEmpty() || type == 1)) { toast("단일 타겟 모드는 클릭 1개만 가능해요"); return }
        val dm = resources.displayMetrics
        val o = ts.size * dp(20)
        val cx = dm.widthPixels / 2 + o; val cy = dm.heightPixels / 2 + o
        ts.add(Target(type, cx, cy, cx + dp(120), cy))
        Config.saveCurrent(); refreshMarkers()
    }

    private fun removeLast() {
        if (running) return
        val ts = Config.targets
        if (ts.isNotEmpty()) { ts.removeAt(ts.size - 1); Config.saveCurrent(); refreshMarkers() }
    }

    fun refreshMarkers() {
        if (shownMode < 0) return
        markers.forEach { try { wm.removeView(it) } catch (_: Exception) {} }; markers.clear()
        Config.targets.forEachIndexed { i, t ->
            addMarker(t, i + 1, false)
            if (t.type == 1) addMarker(t, i + 1, true)
        }
    }

    private fun addMarker(t: Target, n: Int, end: Boolean) {
        val size = dp(44)
        val v = TextView(this).apply {
            text = if (end) "→$n" else "$n"; textSize = 14f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(if (end) 0xAAE65100.toInt() else 0xAA1565C0.toInt()); setStroke(dp(2), Color.WHITE)
            }
        }
        val p = mk(size, size, markerFlags(!running))
        p.x = (if (end) t.x2 else t.x) - size / 2
        p.y = (if (end) t.y2 else t.y) - size / 2
        var dx = 0f; var dy = 0f; var sx = 0; var sy = 0
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = p.x; sy = p.y }
                MotionEvent.ACTION_MOVE -> {
                    p.x = sx + (e.rawX - dx).toInt(); p.y = sy + (e.rawY - dy).toInt()
                    wm.updateViewLayout(v, p)
                }
                MotionEvent.ACTION_UP -> {
                    val cx = p.x + size / 2; val cy = p.y + size / 2
                    if (end) { t.x2 = cx; t.y2 = cy } else { t.x = cx; t.y = cy }
                    Config.saveCurrent()
                }
            }
            true
        }
        wm.addView(v, p); markers.add(v)
    }

    private fun setTouchable() {
        markers.forEach {
            val p = it.layoutParams as WLP
            p.flags = markerFlags(!running); wm.updateViewLayout(it, p)
        }
    }

    private fun start() {
        if (Config.targets.isEmpty()) { toast("먼저 ＋ 로 클릭 지점을 추가하세요"); return }
        running = true; idx = 0; loops = 0; lastUser = 0
        playBtn?.text = "⏸"; setTouchable(); h.post(tick)
    }

    fun stop() {
        running = false; barDown = false; h.removeCallbacks(tick)
        if (shownMode >= 0) { playBtn?.text = "▶"; setTouchable() }
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            val ts = Config.targets
            if (ts.isEmpty()) { stop(); return }
            val now = SystemClock.uptimeMillis()
            // 사용자가 화면을 터치하면 잠깐 멈췄다가 자동 재개
            if (barDown) { playBtn?.text = "⏳"; h.postDelayed(this, 100); return }
            if (Config.pauseOnTouch) {
                val wait = lastUser + Config.resumeDelayMs - now
                if (wait > 0) { playBtn?.text = "⏳"; h.postDelayed(this, minOf(wait, 200L)); return }
            }
            playBtn?.text = "⏸"
            if (idx >= ts.size) idx = 0
            val dur = perform(ts[idx++])
            if (idx >= ts.size) {
                idx = 0; loops++
                if (Config.repeat > 0 && loops >= Config.repeat) { h.postDelayed({ stop() }, dur + 100); return }
            }
            h.postDelayed(this, Config.intervalMs + dur)
        }
    }

    private fun perform(t: Target): Long {
        val j = Config.jitter
        fun r() = if (j > 0) Random.nextInt(-j, j + 1) else 0
        val path = Path()
        path.moveTo((t.x + r()).coerceAtLeast(0).toFloat(), (t.y + r()).coerceAtLeast(0).toFloat())
        val dur = if (t.type == 1) {
            path.lineTo((t.x2 + r()).coerceAtLeast(0).toFloat(), (t.y2 + r()).coerceAtLeast(0).toFloat()); 350L
        } else 40L
        val t0 = SystemClock.uptimeMillis()
        gestureUntil = t0 + 150
        eventUntil = t0 + dur + 300
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, dur)).build(), null, null)
        return dur
    }
}
